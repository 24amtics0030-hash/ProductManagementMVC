
using System.Net.Http.Json; // Enables JSON API responses.
using Microsoft.AspNetCore.Mvc; // Imports MVC functionality.
using Microsoft.Extensions.Caching.Memory; // Enables memory caching.
using ProductManagementMVC.Extensions; // Imports discount extension methods.
using ProductManagementMVC.Models; // Imports Product model.

namespace ProductManagementMVC.Controllers; // Defines controller namespace.

public class ProductController : Controller // Creates product controller.
{
    private readonly IHttpClientFactory _httpClientFactory; // Stores HTTP client factory.
    private readonly IMemoryCache _cache; // Stores memory cache service.
    private const string CacheKey = "ProductList"; // Defines cache key.

    public ProductController(IHttpClientFactory httpClientFactory, IMemoryCache cache)
    {
        _httpClientFactory = httpClientFactory; // Initializes HTTP client factory.
        _cache = cache; // Initializes memory cache.
    }

    private async Task<List<Product>> GetProductsAsync() // Fetches products asynchronously.
    {
        if (_cache.TryGetValue(CacheKey, out List<Product>? cachedProducts))
            return cachedProducts!; // Returns cached products when available.

        var client = _httpClientFactory.CreateClient(); // Creates HTTP client.

        var products = await client.GetFromJsonAsync<List<Product>>(
            "https://fakestoreapi.com/products"); // Fetches products from API.

        products ??= new List<Product>(); // Creates an empty list if response is null.

        _cache.Set(CacheKey, products, TimeSpan.FromMinutes(10)); // Caches products for 10 minutes.

        return products; // Returns the product list.
    }

    public async Task<IActionResult> Index() // Displays product list.
    {
        try
        {
            var products = await GetProductsAsync(); // Retrieves products.

            if (!Request.Cookies.ContainsKey("CustomerName"))
                Response.Cookies.Append("CustomerName", "Guest"); // Creates default customer cookie.

            ViewBag.CustomerName = Request.Cookies["CustomerName"] ?? "Guest"; // Displays Guest if the cookie is missing.
            ViewBag.SelectedCategory =
                HttpContext.Session.GetString("SelectedCategory"); // Reads category from session.

            return View(products); // Displays products.
        }
        catch (HttpRequestException)
        {
            return StatusCode(503, "Product API is unavailable."); // Handles API connection errors.
        }
    }

    [ResponseCache(Duration = 60, Location = ResponseCacheLocation.Client)]
    public async Task<IActionResult> Details(int ProductId) // Receives ID from query string.
    {
        var products = await GetProductsAsync(); // Retrieves products from cache or API.

        var product = products.FirstOrDefault(p => p.ProductId == ProductId); // Finds selected product.

        if (product == null)
            return NotFound(); // Returns 404 if product does not exist.

        ViewBag.DiscountedPrice = product.GetDiscountedPrice(); // Calculates discounted price.

        return View(product); // Displays product details.
    }

    [HttpPost]
    public IActionResult SelectCategory(string category) // Receives selected category.
    {
        HttpContext.Session.SetString("SelectedCategory", category); // Stores category in session.

        return RedirectToAction("Index"); // Returns to product list.
    }

    [HttpPost]
    public IActionResult SetCustomerName(string customerName) // Receives customer name.
    {
        if (!string.IsNullOrWhiteSpace(customerName))
            Response.Cookies.Append("CustomerName", customerName); // Stores name in cookie.

        return RedirectToAction("Index"); // Returns to product list.
    }

    [HttpGet]
    public async Task<IActionResult> Order(int ProductId) // Receives product ID.
    {
        var products = await GetProductsAsync(); // Retrieves product list.

        var product = products.FirstOrDefault(p => p.ProductId == ProductId); // Finds product.

        if (product == null)
            return NotFound(); // Handles missing product.

        return View(product); // Displays order form.
    }

    [HttpPost]
    public IActionResult PlaceOrder(int ProductId) // Receives ID from hidden field.
    {
        TempData["Message"] = $"Order submitted for Product ID: {ProductId}"; // Stores confirmation.

        return RedirectToAction("Index"); // Returns to product list.
    }
}