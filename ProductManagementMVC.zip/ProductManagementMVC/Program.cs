
var builder = WebApplication.CreateBuilder(args); // Creates the application builder.

// Registers MVC controllers and Razor views.
builder.Services.AddControllersWithViews();

// Enables in-memory caching for the product list.
builder.Services.AddMemoryCache();

// Registers in-memory storage for session data.
builder.Services.AddDistributedMemoryCache();

// Configures session management.
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20); // Sets session timeout.
    options.Cookie.HttpOnly = true; // Prevents JavaScript cookie access.
    options.Cookie.IsEssential = true; // Marks the session cookie essential.
});

// Registers HttpClient for asynchronous API requests.
builder.Services.AddHttpClient();

// Registers response caching services.
builder.Services.AddResponseCaching();

// Builds the application.
var app = builder.Build();

// Configures error handling for production.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error"); // Handles application errors.
    app.UseHsts(); // Enables HTTP Strict Transport Security.
}

// Redirects HTTP requests to HTTPS.
app.UseHttpsRedirection();

// Enables static files such as CSS and JavaScript.
app.UseStaticFiles();

// Enables routing.
app.UseRouting();

// Enables response caching middleware.
app.UseResponseCaching();

// Enables session management.
app.UseSession();

// Enables authorization middleware.
app.UseAuthorization();

// Configures the default MVC route.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Product}/{action=Index}/{id?}");

// Starts the application.
app.Run();