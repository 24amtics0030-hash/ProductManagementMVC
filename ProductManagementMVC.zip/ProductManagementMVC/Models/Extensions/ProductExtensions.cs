using ProductManagementMVC.Models; // Imports Product model.

namespace ProductManagementMVC.Extensions; // Defines the extension namespace.

public static class ProductExtensions // Creates a static extension class.
{
    public static decimal GetDiscountedPrice(this Product product) // Adds a method to Product.
    {
        // Calculates the final price after applying the discount.
        return product.Price -
               (product.Price * product.DiscountPercentage / 100);
    }
}