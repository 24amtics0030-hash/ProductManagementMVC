using System.Text.Json.Serialization; // Imports JSON attributes.

namespace ProductManagementMVC.Models; // Defines the model namespace.

public class Product // Defines the Product class.
{
    [JsonPropertyName("id")] // Maps API id to ProductId.
    public int ProductId { get; set; } // Stores product ID.

    [JsonPropertyName("title")] // Maps API title to ProductName.
    public string ProductName { get; set; } = string.Empty; // Stores product name.

    [JsonPropertyName("category")] // Maps API category.
    public string Category { get; set; } = string.Empty; // Stores category.

    [JsonPropertyName("price")] // Maps API price.
    public decimal Price { get; set; } // Stores product price.

    public decimal DiscountPercentage { get; set; } = 10; // Sets a default 10% discount.
}